//#define USE_DLL
#pragma once
#include "BlowFish.h"
using namespace System;

namespace BlowFishClassLibrary {
	//warpper class
	//class BlowFishClass;
#ifndef USE_DLL
	public ref class BlowFishClass
	{
	private:
		BlowFish* blowFish;

	public:
		// TODO: Add your methods for this class here.

		DWORD Encode(BYTE* key, int keybytes, BYTE* pInput, BYTE* pOutput, DWORD lSize);
		void Decode(BYTE* key, int keybytes, BYTE* pInput, BYTE* pOutput, DWORD lSize);
	};
#else
	BlowFish blowFish;
	extern "C" __declspec(dllexport) DWORD __stdcall Encode(BYTE* key, int keybytes, 
												BYTE* pInput, BYTE* pOutput, DWORD lSize) 
	{
		return blowFish.Encode(key, keybytes, pInput, pOutput, lSize);
	};
	
	extern "C" __declspec(dllexport) void __stdcall Decode(BYTE* key, int keybytes, 
										BYTE* pInput, BYTE* pOutput, DWORD lSize) 
	{
		blowFish.Decode(key, keybytes, pInput, pOutput, lSize);
	};
#endif
}
