// dllmain.cpp : Defines the entry point for the DLL application.
#include "pch.h"
#include "BlowFishLib.h"

__declspec(dllexport) DWORD _Encode(BYTE key[], int keybytes, BYTE pInput[], BYTE* pOutput, DWORD lSize)
{
    BlowFishLib blowFishLib;
    return blowFishLib.Encode(key, keybytes, pInput, pOutput, lSize);
}

__declspec(dllexport) void _Decode(BYTE key[], int keybytes, BYTE pInput[], BYTE* pOutput, DWORD lSize)
{
    BlowFishLib blowFishLib;
    return blowFishLib.Decode(key, keybytes, pInput, pOutput, lSize);
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

